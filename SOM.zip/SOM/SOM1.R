##SOM
##le package kohonen:
##install.packages("kohonen")
library("kohonen") ##charger le package
##data iris 
data(iris)
print(summary(iris)) ##l'affichage du resume
##donnees centrees reduites
Z<-scale(iris[,1:4],center=T,scale=T)
##apprentissage carte hexagonale:
grid1<-somgrid(xdim =10,ydim=10,topo="hexagonal",toroidal=TRUE) ##Dans cette commande, nous avons demande une grille hexagonale de taille 10 x 10.
##Dans les cartes toroidales, les limites aux bords ne seront affichees que sur les cotes superieur et droit pour eviter les doubles limites.
##SOM:
set.seed(40) ##pour specifier les seeds
carte1<-som(Z,grid=grid1,rlen=700,alpha=c(0.05,0.01),keep.data=TRUE) 
carte1
summary(carte1) ##l'affichage du resume
##nombre d'observations dans les cellules
plot(carte1,type="count")
plot(carte1,type="dist.neighbours",palette.name=grey.colors,shape="straight") ##indique la somme des distances a tous les voisins immediats.
plot(carte1,type="quality",shape="straight") ##quality plot
##Plus les distances sont petites, les objets sont mieux representes par les vecteurs du codebook
plot(carte1,type="codes",codeRendering="stars") ##les vecteurs du codebook
##profile des cellules - codebook
plot(carte1,type="codes",codeRendering="segments") ##segments
plot(carte1,type="codes",codeRendering="lines") ##lignes
#degrade de bleu pour les couleurs des noeuds
bleu<-function(n){
  return(rgb(0,0.4,1,alpha=seq(1/n,1,1/n)))
}
##nombre d'observations dans les cellules
plot(carte1,type="count",palette.name=bleu)
plot(carte1,type="mapping",border="black") ##mapping plot ##Le nombre inferieur de cellules vides
plot(carte1,type="mapping",border="black",shape ="straight") ##straight form
variable<-1 #definir la variable a tracer 
plot(carte1,type="property",property=getCodes(carte1)[,variable],main=colnames(getCodes(carte1))[variable],palette.name=bleu)
variable1<-2 
plot(carte1,type="property",property=getCodes(carte1)[,variable1],main=colnames(getCodes(carte1))[variable1],palette.name=bleu)
variable2<-3 
plot(carte1,type="property",property=getCodes(carte1)[,variable2],main=colnames(getCodes(carte1))[variable2],palette.name=bleu)
variable3<-4  
plot(carte1,type="property",property=getCodes(carte1)[,variable3],main=colnames(getCodes(carte1))[variable3],palette.name=bleu)
